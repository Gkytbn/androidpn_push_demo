package com.example.demopush;

import com.push.common.ApplicationInit;

import android.app.Application;

public class application extends Application {
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		//ApplicationInit.initSystemVersion(getApplicationContext());
		ApplicationInit.startDaemonService(this);
	}
}
