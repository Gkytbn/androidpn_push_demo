package com.example.demopush;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

public class MyDialogFragment extends DialogFragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
		//setStyle(DialogFragment.STYLE_NO_FRAME, R.style.Theme_Dialog_Fragment);
		setCancelable(false);

		this.getDialog().setOnKeyListener(new DialogInterface.OnKeyListener() {
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
					MyDialogFragment.this.dismiss();
					return true; // pretend we've processed it
				} else
					return false; // pass on to be processed as normal
			}
		});

		this.getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		View view = inflater.inflate(R.layout.dialog, container);

		ImageView iv = (ImageView) view.findViewById(R.id.imageView1);
		RotateAnimation rotate = new RotateAnimation(0f, 360f, Animation.RELATIVE_TO_SELF, 0.5f,
				Animation.RELATIVE_TO_SELF, 0.5f);
		LinearInterpolator lin = new LinearInterpolator();
		rotate.setInterpolator(lin);
		rotate.setDuration(1500);// 设置动画持续时间
		rotate.setRepeatCount(-1);// 设置重复次数
		rotate.setFillAfter(true);// 动画执行完后是否停留在执行完的状�?
		iv.setAnimation(rotate);
		return view;
	}

}
