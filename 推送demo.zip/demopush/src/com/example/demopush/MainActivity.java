package com.example.demopush;


import com.push.common.ApplicationInit;
import com.push.manger.ServiceManager;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	ServiceManager serviceManager = new ServiceManager(MainActivity.this);
		String phone = getSharedPreferences("phone", Context.MODE_PRIVATE).getString("num", "123456789");

		if (phone.equals("") || phone.equals("123456789")) {
			phone = "13" + (int) (Math.random() * (999999999 - 100000000 + 1));
			//phone="wujia";
			getSharedPreferences("phone", Context.MODE_PRIVATE).edit().putString("num", phone);
		}
		
		serviceManager.setUserName(this, phone);
		serviceManager.setNotificationIcon(R.drawable.ic_launcher);
		serviceManager.startService();

	}
}
