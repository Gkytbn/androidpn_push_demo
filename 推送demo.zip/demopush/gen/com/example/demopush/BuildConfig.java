/** Automatically generated file. DO NOT MODIFY */
package com.example.demopush;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}