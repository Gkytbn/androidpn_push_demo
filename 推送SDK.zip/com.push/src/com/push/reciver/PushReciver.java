package com.push.reciver;

import java.util.ArrayList;

import com.push.common.ApplicationInit;
import com.push.service.PushService;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.util.Log;
import android.widget.Toast;

public class PushReciver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
	
		if (!ApplicationInit.isServiceWorked(context, ApplicationInit.Process_NameForPushService)) {
			// context.startService(new Intent(context, Service1.class));
			if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
				Intent i = new Intent();
				Toast.makeText(context, "开机启动广播", 0).show();
				i.setClass(context, PushService.class);
				context.startService(i);
			} else if (Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
				Toast.makeText(context, "锁屏广播", 0).show();
				Intent i = new Intent();
				i.setClass(context, PushService.class);
				context.startService(i);
			} else if ("com.example.service_destory".equals(intent.getAction())) {
				Toast.makeText(context, "service_destory广播", 0).show();
				Intent i = new Intent();
				i.setClass(context, PushService.class);
				context.startService(i);
			} else if ("android.intent.action.ACTION_POWER_CONNECTED".equals(intent.getAction())) {
				Toast.makeText(context, "充电广播", 0).show();
				Intent i = new Intent();
				i.setClass(context, PushService.class);
				context.startService(i);
			}else if ("android.net.wifi.WIFI_STATE_CHANGED".equals(intent.getAction())) {
				Toast.makeText(context, "wifi 状态广播", 0).show();
				Intent i = new Intent();
				i.setClass(context, PushService.class);
				context.startService(i);
			}else if ("android.net.wifi.STATE_CHANGE".equals(intent.getAction())) {
				Toast.makeText(context, "wifi STATE_CHANGE 广播", 0).show();
				Intent i = new Intent();
				i.setClass(context, PushService.class);
				context.startService(i);
			}
		}
	}

}
