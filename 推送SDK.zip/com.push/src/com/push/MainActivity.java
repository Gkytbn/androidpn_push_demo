package com.push;

import com.push.manger.ServiceManager;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		String phone = getSharedPreferences("phone", Context.MODE_PRIVATE).getString("num", "123456789");
		if (phone.equals("") || phone.equals("123456789")) {
			phone = "13" + (int) (Math.random() * (999999999 - 100000000 + 1));
			// phone="wujia";
			getSharedPreferences("phone", Context.MODE_PRIVATE).edit().putString("num", phone);
		}
		ServiceManager serviceManager = ServiceManager.getInstence(this);
		serviceManager.setNotificationIcon(R.drawable.ic_launcher);
		serviceManager.setUserName(this, phone);
		serviceManager.startService();
	}
}
