package com.push.service;

import java.io.IOException;
import java.io.InputStreamReader;

import com.push.MyApplication;
import com.push.common.ApplicationInit;
import com.push.manger.ServiceManager;

import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class DaemonService extends Service {
	public native static void forkDaemon(String proName, int cmdType);

	static {
		System.loadLibrary("daemon");
	}

	public static final String START_DAEMON_ACTION = "com.ssdj.cloudroom.ACTION_START_DAEMON";

	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this, "DaemonService 启动 ", 1).show();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Toast.makeText(this, "DaemonService重新启动", 1).show();
		if (intent == null) {
			stopSelf();
			return super.onStartCommand(intent, flags, startId);
		}
		String action = intent.getAction();
		String proName = this.getApplicationInfo().packageName;
		int cmdType = initSystemVersion(getApplicationContext());;
		System.out.println("-----------------》" + cmdType);
		// int cmdType = ServiceManager.getInstence(this).systemVersion;
		if (START_DAEMON_ACTION.equals(action)) {
			forkDaemon(proName, cmdType);// ���¿����ػ�����
			Toast.makeText(this, "DaemonService  C端守护开启", 0).show();
		}
		stopSelf();
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	private Application context;

	public void setContext(Application context) {
		this.context = context;

	}

	public int  initSystemVersion(Context context) {
		int systemVersion = 0;
		Process p = null;
		try {
			p = Runtime.getRuntime().exec("/system/bin/am abcd");// 确保输出错误日志
			InputStreamReader isr = new InputStreamReader(p.getErrorStream());
			char[] buf = new char[1024];
			while (isr.read(buf) > 0) {
				String tmp = new String(buf);
				if (tmp.contains("--user"))
					ApplicationInit.systemVersion = 1;
			}
		} catch (IOException e) {
			// Do noting
		} catch (NullPointerException e) {
			// Do noting
		} finally {

			if (p != null)
				p.destroy();
		}
		//System.out.println("----------------------------->" + systemVersion);
		return systemVersion;
	}
	
}
