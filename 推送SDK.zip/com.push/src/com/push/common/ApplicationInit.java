package com.push.common;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.push.service.DaemonService;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.Context;
import android.content.Intent;

/**
 * @author gzbd_kfb_002
 *
 */
public class ApplicationInit {

	public static int systemVersion = 0;
	public static String name ="";
	public static String Process_NameForPushService = "com.push.service.PushService";

	/**
	 * @param context
	 *            ���봫 getApplicationContext()
	 */
	public static void initSystemVersion(Context context ) {
		Process p = null;
		try {
			p = Runtime.getRuntime().exec("/system/bin/am abcd");// ȷ�����������־
			InputStreamReader isr = new InputStreamReader(p.getErrorStream());
			char[] buf = new char[1024];
			while (isr.read(buf) > 0) {
				String tmp = new String(buf);
				if (tmp.contains("--user"))
					ApplicationInit.systemVersion = 1;
			}
		} catch (IOException e) {
			// Do noting
		} catch (NullPointerException e) {
			// Do noting
		} finally {
			
			if (p != null)
				p.destroy();
		}
		System.out.println("----------------------------->"+systemVersion);

	}


	/**
	 * @param context
	 *            ���봩 this
	 */
	public static void startDaemonService(Context context) {
		Intent intent = new Intent(context, DaemonService.class);
		intent.setAction(DaemonService.START_DAEMON_ACTION);
		context.startService(intent);
		
	}

	public static boolean isServiceWorked(Context context, String serviceName) {
		ActivityManager myManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		ArrayList<RunningServiceInfo> runningService = (ArrayList<RunningServiceInfo>) myManager
				.getRunningServices(Integer.MAX_VALUE);
		for (int i = 0; i < runningService.size(); i++) {
			// System.out.println("---？�?��?��??-----�?"+runningService.get(i).service.getClassName().toString());
			if (runningService.get(i).service.getClassName().toString().equals(serviceName)) {

				return true;
			}
		}
		return false;
	}
}
