package com.push.manger;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Handler;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Future;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionConfiguration.SecurityMode;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.AndFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketIDFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.IQ.Type;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Registration;
import org.jivesoftware.smack.packet.XMPPError;
import org.jivesoftware.smack.provider.ProviderManager;

import com.push.common.LogUtil;
import com.push.common.ReconnectionThread;
import com.push.listener.PersistentConnectionListener;
import com.push.notification.NotificationIQ;
import com.push.notification.NotificationIQProvider;
import com.push.notification.NotificationPacketListener;
import com.push.service.PushService;

public class XmppManager {
	private static final String LOGTAG = LogUtil.makeLogTag(XmppManager.class);
	private static final String XMPP_RESOURCE_NAME = "AndroiClient";
	private Context context;
	private PushService.TaskSubmitter taskSubmitter;
	private PushService.TaskTracker taskTracker;
	private SharedPreferences sharedPrefs;
	private String xmppHost;
	private int xmppPort;
	private XMPPConnection connection;
	private String username;
	private String password;
	private ConnectionListener connectionListener;
	private PacketListener notificationPacketListener;
	private Handler handler;
	private List<Runnable> taskList;
	private boolean running = false;
	private Future<?> futureTask;
	private Thread reconnection;

	public XmppManager(PushService notificationService) {
		this.context = notificationService;
		this.taskSubmitter = notificationService.getTaskSubmitter();
		this.taskTracker = notificationService.getTaskTracker();
		this.sharedPrefs = notificationService.getSharedPreferences();

		this.xmppHost = this.sharedPrefs.getString("XMPP_HOST", "localhost");
		this.xmppPort = this.sharedPrefs.getInt("XMPP_PORT", 5222);
		this.username = this.sharedPrefs.getString("XMPP_USERNAME", "");
		this.password = this.sharedPrefs.getString("XMPP_PASSWORD", "");

		this.connectionListener = new PersistentConnectionListener(this);
		this.notificationPacketListener = new NotificationPacketListener(this);

		this.handler = new Handler();
		this.taskList = new ArrayList();
		this.reconnection = new ReconnectionThread(this);
	}

	public Context getContext() {
		return this.context;
	}

	public void connect() {
		Log.d(LOGTAG, "connect()...");
		submitLoginTask();
	}

	public void disconnect() {
		Log.d(LOGTAG, "disconnect()...");
		terminatePersistentConnection();
	}

	public void terminatePersistentConnection() {
		Log.d(LOGTAG, "terminatePersistentConnection()...");
		Runnable runnable = new Runnable() {
			final XmppManager xmppManager = XmppManager.this;

			public void run() {
				if (this.xmppManager.isConnected()) {
					Log.d(XmppManager.LOGTAG, "terminatePersistentConnection()... run()");
					this.xmppManager.getConnection()
							.removePacketListener(this.xmppManager.getNotificationPacketListener());
					this.xmppManager.getConnection().disconnect();
				}
				this.xmppManager.runTask();
			}
		};
		addTask(runnable);
	}

	public XMPPConnection getConnection() {
		return this.connection;
	}

	public void setConnection(XMPPConnection connection) {
		this.connection = connection;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public ConnectionListener getConnectionListener() {
		return this.connectionListener;
	}

	public PacketListener getNotificationPacketListener() {
		return this.notificationPacketListener;
	}

	public void startReconnectionThread() {
		synchronized (this.reconnection) {
			if (!this.reconnection.isAlive()) {
				this.reconnection.setName("Xmpp Reconnection Thread");
				this.reconnection.start();
			}
		}
	}

	public Handler getHandler() {
		return this.handler;
	}

	public void reregisterAccount() {
		removeAccount();
		submitLoginTask();
		runTask();
	}

	public List<Runnable> getTaskList() {
		return this.taskList;
	}

	public Future<?> getFutureTask() {
		return this.futureTask;
	}

	public void runTask() {
		Log.d(LOGTAG, "runTask()...");
		synchronized (this.taskList) {
			this.running = false;
			this.futureTask = null;
			if (!this.taskList.isEmpty()) {
				Runnable runnable = (Runnable) this.taskList.get(0);
				this.taskList.remove(0);
				this.running = true;
				this.futureTask = this.taskSubmitter.submit(runnable);
				if (this.futureTask == null) {
					this.taskTracker.decrease();
				}
			}
		}
		this.taskTracker.decrease();
		Log.d(LOGTAG, "runTask()...done");
	}

	private String newRandomUUID() {
		String uuidRaw = UUID.randomUUID().toString();
		return uuidRaw.replaceAll("-", "");
	}

	private boolean isConnected() {
		return (this.connection != null) && (this.connection.isConnected());
	}

	private boolean isAuthenticated() {
		return (this.connection != null) && (this.connection.isConnected()) && (this.connection.isAuthenticated());
	}

	private boolean isRegistered() {
		return (this.sharedPrefs.contains("XMPP_USERNAME")) && (this.sharedPrefs.contains("XMPP_PASSWORD"));
	}

	private void submitConnectTask() {
		Log.d(LOGTAG, "submitConnectTask()...");
		addTask(new ConnectTask());
	}

	private void submitRegisterTask() {
		Log.d(LOGTAG, "submitRegisterTask()...");
		submitConnectTask();
		addTask(new RegisterTask());
	}

	private void submitLoginTask() {
		Log.d(LOGTAG, "submitLoginTask()...");
		submitRegisterTask();
		addTask(new LoginTask());
	}

	private void addTask(Runnable runnable) {
		Log.d(LOGTAG, "addTask(runnable)...");
		this.taskTracker.increase();
		synchronized (this.taskList) {
			if ((this.taskList.isEmpty()) && (!this.running)) {
				this.running = true;
				this.futureTask = this.taskSubmitter.submit(runnable);
				if (this.futureTask == null) {
					this.taskTracker.decrease();
				}

			} else {
				this.taskList.add(runnable);
				runTask();
			}
		}
		Log.d(LOGTAG, "addTask(runnable)... done");
	}

	private void removeAccount() {
		SharedPreferences.Editor editor = this.sharedPrefs.edit();
		editor.remove("XMPP_USERNAME");
		editor.remove("XMPP_PASSWORD");
		editor.commit();
	}

	private class ConnectTask implements Runnable {
		final XmppManager xmppManager;

		private ConnectTask() {
			this.xmppManager = XmppManager.this;
		}

		public void run() {
			Log.i(XmppManager.LOGTAG, "ConnectTask.run()...");

			if (!this.xmppManager.isConnected()) {
				ConnectionConfiguration connConfig = new ConnectionConfiguration(XmppManager.this.xmppHost,
						XmppManager.this.xmppPort);

				connConfig.setSecurityMode(ConnectionConfiguration.SecurityMode.required);
				connConfig.setSASLAuthenticationEnabled(false);
				connConfig.setCompressionEnabled(false);

				SmackConfiguration.setKeepAliveInterval(400000000);
				XMPPConnection connection = new XMPPConnection(connConfig);
				System.out.println("--------------------------->" + SmackConfiguration.getKeepAliveInterval());

				// connection.setKeepAliveInterval
				this.xmppManager.setConnection(connection);
				try {
					connection.connect();
					Log.i(XmppManager.LOGTAG, "XMPP connected successfully");

					ProviderManager.getInstance().addIQProvider("notification", "androidpn:iq:notification",
							new NotificationIQProvider());
				} catch (XMPPException e) {
					Log.e(XmppManager.LOGTAG, "XMPP connection failed", e);
				}

				this.xmppManager.runTask();
			} else {
				Log.i(XmppManager.LOGTAG, "XMPP connected already");
				this.xmppManager.runTask();
			}
		}
	}

	private class LoginTask implements Runnable {
		final XmppManager xmppManager;

		private LoginTask() {
			this.xmppManager = XmppManager.this;
		}

		public void run() {
			Log.i(XmppManager.LOGTAG, "LoginTask.run()...");

			if (!this.xmppManager.isAuthenticated()) {
				Log.d(XmppManager.LOGTAG, "username=" + XmppManager.this.username);
				Log.d(XmppManager.LOGTAG, "password=" + XmppManager.this.password);
				try {
					this.xmppManager.getConnection().login(this.xmppManager.getUsername(),
							this.xmppManager.getPassword(), "AndroidpnClient");
					Log.d(XmppManager.LOGTAG, "Loggedn in successfully");

					if (this.xmppManager.getConnectionListener() != null) {
						this.xmppManager.getConnection()
								.addConnectionListener(this.xmppManager.getConnectionListener());
					}

					PacketFilter packetFilter = new PacketTypeFilter(NotificationIQ.class);

					PacketListener packetListener = this.xmppManager.getNotificationPacketListener();
					XmppManager.this.connection.addPacketListener(packetListener, packetFilter);

					this.xmppManager.runTask();
				} catch (XMPPException e) {
					Log.e(XmppManager.LOGTAG, "LoginTask.run()... xmpp error");
					Log.e(XmppManager.LOGTAG, "Failed to login to xmpp server. Caused by: " + e.getMessage());
					String INVALID_CREDENTIALS_ERROR_CODE = "401";
					String errorMessage = e.getMessage();
					if ((errorMessage != null) && (errorMessage.contains(INVALID_CREDENTIALS_ERROR_CODE))) {
						this.xmppManager.reregisterAccount();
						return;
					}
					this.xmppManager.startReconnectionThread();
				} catch (Exception e) {
					Log.e(XmppManager.LOGTAG, "LoginTask.run()... other error");
					Log.e(XmppManager.LOGTAG, "Failed to login to xmpp server. Caused by: " + e.getMessage());
					this.xmppManager.startReconnectionThread();
				}
			} else {
				Log.i(XmppManager.LOGTAG, "Logged in already");
				this.xmppManager.runTask();
			}
		}
	}

	private class RegisterTask implements Runnable {
		final XmppManager xmppManager;
		private String newPassword = XmppManager.this.password;
		private String newUsername = XmppManager.this.username;

		private RegisterTask() {
			this.xmppManager = XmppManager.this;
		}

		public void run() {
			Log.i(XmppManager.LOGTAG, "RegisterTask.run()...");

			if (!this.xmppManager.isRegistered()) {
				if (this.newPassword.trim().equals("")) {
					this.newUsername = XmppManager.this.newRandomUUID();
					this.newPassword = XmppManager.this.newRandomUUID();
				}

				Registration registration = new Registration();

				PacketFilter packetFilter = new AndFilter(new PacketFilter[] {
						new PacketIDFilter(registration.getPacketID()), new PacketTypeFilter(IQ.class) });

				PacketListener packetListener = new PacketListener() {
					public void processPacket(Packet packet) {
						Log.d("RegisterTask.PacketListener", "processPacket().....");
						Log.d("RegisterTask.PacketListener", "packet=" + packet.toXML());

						if ((packet instanceof IQ)) {
							IQ response = (IQ) packet;
							if (response.getType() == IQ.Type.ERROR) {
								if (!response.getError().toString().contains("409"))
									Log.e(XmppManager.LOGTAG, "Unknown error while registering XMPP account! "
											+ response.getError().getCondition());
							} else if (response.getType() == IQ.Type.RESULT) {
								XmppManager.RegisterTask.this.xmppManager
										.setUsername(XmppManager.RegisterTask.this.newUsername);
								XmppManager.RegisterTask.this.xmppManager
										.setPassword(XmppManager.RegisterTask.this.newPassword);
								Log.d(XmppManager.LOGTAG, "username=" + XmppManager.RegisterTask.this.newUsername);
								Log.d(XmppManager.LOGTAG, "password=" + XmppManager.RegisterTask.this.newPassword);

								SharedPreferences.Editor editor = XmppManager.this.sharedPrefs.edit();
								editor.putString("XMPP_USERNAME", XmppManager.RegisterTask.this.newUsername);
								editor.putString("XMPP_PASSWORD", XmppManager.RegisterTask.this.newPassword);
								editor.commit();
								Log.i(XmppManager.LOGTAG, "Account registered successfully");
								XmppManager.RegisterTask.this.xmppManager.runTask();
							}
						}
					}
				};
				XmppManager.this.connection.addPacketListener(packetListener, packetFilter);

				registration.setType(IQ.Type.SET);

				registration.addAttribute("username", this.newUsername);
				registration.addAttribute("password", this.newPassword);
				XmppManager.this.connection.sendPacket(registration);
			} else {
				Log.i(XmppManager.LOGTAG, "Account registered already");
				this.xmppManager.runTask();
			}
		}
	}
}