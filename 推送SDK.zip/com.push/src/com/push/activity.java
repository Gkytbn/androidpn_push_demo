package com.push;

import java.lang.reflect.Method;
import java.util.List;

import com.push.common.Constants;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.View.OnKeyListener;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class activity extends FragmentActivity {
	private MyDialogFragment myDialogFragment;
	private int screenWidth;
	private ActionBar actionBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		myDialogFragment = new MyDialogFragment();
		myDialogFragment.show(getSupportFragmentManager(), "dilog");
		actionBar = getActionBar();
		actionBar.show();
		actionBar.setDisplayShowTitleEnabled(true);
		actionBar.setDisplayHomeAsUpEnabled(true); // �������Ͻ�ͼ����Ҳ��Ƿ��������С��ͷ, true
													// ��С��ͷ������ͼ����Ե��
		actionBar.setDisplayShowHomeEnabled(false);
		Intent intent = getIntent();
		String notificationId = intent.getStringExtra(Constants.NOTIFICATION_ID);
		String notificationApiKey = intent.getStringExtra(Constants.NOTIFICATION_API_KEY);
		String notificationTitle = intent.getStringExtra(Constants.NOTIFICATION_TITLE);
		String notificationMessage = intent.getStringExtra(Constants.NOTIFICATION_MESSAGE);
		notificationUri = intent.getStringExtra(Constants.NOTIFICATION_URI);
		webView = new WebView(this);
		setContentView(webView);
		webView.setWebViewClient(viewClient);

		screenWidth = getScreenWidth(this);
		webView.getSettings().setJavaScriptEnabled(true);
		MyWebChromeClient client = new MyWebChromeClient();
		webView.setWebChromeClient(client);
		webView.setWebViewClient(viewClient);
		webView.getSettings().setSupportZoom(true);
		webView.getSettings().setBuiltInZoomControls(true);
		// �������������
		webView.getSettings().setUseWideViewPort(true);
		// ����Ӧ��Ļ
		webView.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		webView.getSettings().setLoadWithOverviewMode(true);
		if (!notificationUri.equals(""))
			webView.loadUrl(notificationUri);
		webView.setOnKeyListener(listener);

	}

	class MyWebChromeClient extends WebChromeClient {
		@Override
		public void onProgressChanged(WebView view, int newProgress) {
			if (newProgress == 100) {
				myDialogFragment.dismiss();
			} else {
				// progree_view.setVisibility(View.VISIBLE);
				// LayoutParams params = progree_view.getLayoutParams();
				// params.width = newProgress * screenWidth / 100;
				// progree_view.setLayoutParams(params);
				// // progree_view.setWidth(newProgress * screenWidth / 100);

			}
			super.onProgressChanged(view, newProgress);
		}
	}

	public static int getScreenWidth(Context context) {
		WindowManager wm = (WindowManager) context.getSystemService("window");
		DisplayMetrics dm = new DisplayMetrics();
		wm.getDefaultDisplay().getMetrics(dm);
		return dm.widthPixels;
	}

	OnKeyListener listener = new OnKeyListener() {

		@Override
		public boolean onKey(View v, int keyCode, KeyEvent event) {
			if (event.getAction() == KeyEvent.ACTION_DOWN)
				if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
					webView.goBack();
					return true;
				}
			return false;
		}
	};
	WebViewClient viewClient = new WebViewClient() {
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		};
	};
	private WebView webView;
	private String notificationUri;

	@Override
	public boolean onMenuOpened(int featureId, Menu menu) {
		// TODO Auto-generated method stub
		setOverflowIconVisible(featureId, menu);
		return super.onMenuOpened(featureId, menu);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		super.onCreateOptionsMenu(menu);
		getMenuInflater().inflate(R.menu.menu, menu);

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.share:
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/html"); // "image/*"
			intent.putExtra(Intent.EXTRA_SUBJECT, "������ַ");
			intent.putExtra(Intent.EXTRA_TEXT, "�����ǻ������������ö����������һ�£�" +notificationUri );
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(Intent.createChooser(intent, "ѡ���������"));
			// shareTencent();
			break;
			
		case android.R.id.home:
//			Intent intent2 =new Intent(this,com.intelligent.DetegateMainActivity);
//			startActivity(intent2);
//			break;
		}
		return super.onOptionsItemSelected(item);

	}

	/**
	 * @param featureId
	 *            ���� ���� overflowmenu ��ͼ����
	 * @param menu
	 */
	public static void setOverflowIconVisible(int featureId, Menu menu) {
		if (featureId == Window.FEATURE_ACTION_BAR && menu != null) {
			if (menu.getClass().getSimpleName().equals("MenuBuilder")) {
				try {
					Method m = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
					m.setAccessible(true);
					m.invoke(menu, true);
				} catch (Exception e) {
				}
			}
		}

	}

	public void shareTencent() {
		boolean found = true;
		String type = "com.tencent.mm";
		Intent share = new Intent(android.content.Intent.ACTION_SEND);
		share.setType("text/plain");
		// gets the list of intents that can be loaded.
		List<ResolveInfo> resInfo = getPackageManager().queryIntentActivities(share, 0);
		if (!resInfo.isEmpty()) {
			for (ResolveInfo info : resInfo) {
				if (info.activityInfo.packageName.toLowerCase().contains(type)
						|| info.activityInfo.name.toLowerCase().contains(type)) {
					share.putExtra(Intent.EXTRA_SUBJECT, "�������һ�����»");
					share.putExtra(Intent.EXTRA_TEXT, "www.baidu.com");
					// share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new
					// File(myPath))); //
					share.setPackage(info.activityInfo.packageName);
					found = true;
					break;
				}
			}
			if (!found)
				return;
			startActivity(Intent.createChooser(share, "ѡ��"));
		}
	}

}
