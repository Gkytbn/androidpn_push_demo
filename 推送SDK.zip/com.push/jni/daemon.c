#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include<unistd.h>
#include <dirent.h>
#include <android/log.h>
#define LOGD(...) __android_log_print(ANDROID_LOG_INFO, "Daemon", __VA_ARGS__);

/* 查找当前有多少个该进程名的进程
 * const char *process_name 需要查找的进程名
 * return 总共的梳理
 */
int find_process_amount(const char *process_name) {
	int id;
	DIR* dir;
	FILE *fp;
	char filename[32];
	char cmdline[256];
	int process_amount = 0;

	struct dirent * entry;
	if (process_name == NULL)
		return -1;

	dir = opendir("/proc");
	if (dir == NULL)
		return -1;

	while ((entry = readdir(dir)) != NULL) {
		id = atoi(entry->d_name);
		if (id != 0) {
			sprintf(filename, "/proc/%d/cmdline", id);
			fp = fopen(filename, "r");
			if (fp) {
				fgets(cmdline, sizeof(cmdline), fp);
				fclose(fp);
				if (strcmp(process_name, cmdline) == 0)
						{
					/* process found */
					process_amount++;
					LOGD("found %d processes,id = %d !And clear cmdline !\n",
							process_amount, id);
					memset(cmdline, 0, sizeof(cmdline));
				}
			}
		}
	}

	closedir(dir);
	return process_amount;
}

/* 开启守护进程
 * JNIEnv* env 虚拟机环境变量
 * jobject thiz
 * jstring p_name 应用包名
 * cmd_type 命令类型，根据不同系统版本，拼接不同的命令
 *
 */
Java_com_push_service_DaemonService_forkDaemon(JNIEnv* env,
		jobject thiz, jstring p_name, jint cmd_type) {
	char cmd[256];
	char time_str[15];
	const char*process_name = (*env)->GetStringUTFChars(env, p_name, 0);
	int process_amount = find_process_amount(process_name);
	LOGD(
			"find porcess whose name is %s ,and the amount of this process is  %d !\n",
			process_name, process_amount);
	if (process_amount == 1)
			{
		if (cmd_type == 1)
			strcpy(cmd, "am startservice --user 0 -n ");
		else if (cmd_type == 0)
			strcpy(cmd, "am startservice -n ");
		else
			return;
		strcat(cmd, process_name);
		strcat(cmd, "/com.push.service.PushService");
		(*env)->ReleaseStringUTFChars(env, p_name, process_name);
		pid_t pid = fork();
		if (pid < 0)
				{
			LOGD("fork child error��\n");
			return;
		} else if (pid == 0)
				{
			LOGD("this is in child process,pid = %d\n", pid);
			while (1) {
				sleep(5);
				if (getppid() == 1)
						{
					LOGD("cmd = %s\n", cmd);
					FILE *p = popen(cmd, "r");
					if (p == NULL) {
						LOGD("error :%s\n", strerror(errno));
					} else {
						LOGD("start service success!\n");
					}
					exit(0);
				}
			}
		} else if (pid > 0)
				{
			LOGD("this is in parent process,child_pid = %d parent_pid = %d\n",
					pid, getpid());
			return;
		}
	} else if (process_amount == 2) {

		LOGD(
				"There is 2 processes whose name are %s! It's not necessary to fork a daemon process!\n",
				process_name);
		return;

	} else {
		LOGD("Not found this process of %s!", process_name);
		return;
	}

}
