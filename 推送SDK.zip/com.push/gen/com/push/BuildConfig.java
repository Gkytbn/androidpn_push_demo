/** Automatically generated file. DO NOT MODIFY */
package com.push;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}